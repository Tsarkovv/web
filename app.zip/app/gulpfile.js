var gulp = require('gulp');
var minCSS = require('gulp-clean-css');
var rename = require('gulp-rename');
var minify = require('gulp-minify');
browserSync = require('browser-sync').create();

gulp.task('move', async function() {
	gulp.src('/css/main.css')
	.pipe(gulp.dest('public/css'));
});

gulp.task('smallCSS', async function(){
	gulp.src('/css/main.css')
	.pipe(minCSS())
	.pipe(rename({
		suffix: '.min'
	}))
	.pipe(gulp.dest('public/css'))
	.pipe(browserSync.stream());
});

gulp.task('minJS', async function(){
	gulp.src('/js/main.js')
	.pipe(minify())
	.pipe(rename({
		suffix: '.min'
	}))
	.pipe(gulp.dest('public/js'))
	.pipe(browserSync.stream());
});

function watchAll() {
	// Проверка различных изменений в файлах и вызов соответсвующих функций
	gulp.watch("/css/*.css", ['smallCSS']);
	gulp.watch("/js/*.js", ['minJS']);
}

gulp.task('browserWork', async function(){
	browserSync.init({
		server: "public/"
	});

	gulp.watch("public/*.html").on('change', browserSync.reload);
});

gulp.task('default', gulp.parallel('browserWork', 'minJS'));