// Avoid `console` errors in browsers that lack a console.

// Place any jQuery/helper plugins in here.
