jQuery(document).ready(function(){
    
    var header = $('.header');
    var nav = $('.nav-header');
    
    window.onscroll = function() {
        if(window.pageYOffset > header.height()){
            nav.addClass('nav-move');
        } else{
            nav.removeClass('nav-move');
        }
    }
    
    $('#mc-form').ajaxChimp({
    url: 'https://bk.us19.list-manage.com/subscribe/post?u=921302185002eb47733a0307b&amp;id=26d2d61cd9'
});
    
    $(".burger").click(function(){
  $(".burger").toggleClass("is-active");
});
});